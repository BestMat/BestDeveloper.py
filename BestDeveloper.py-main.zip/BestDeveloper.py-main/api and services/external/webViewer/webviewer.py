import webview
webview.create_window('Hello world', 'https://python.org')
webview.start()
