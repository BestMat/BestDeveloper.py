import requests 
def get():
 r = requests.get(url = u, params = PARAMS) 
 data = r.json()
 return r
