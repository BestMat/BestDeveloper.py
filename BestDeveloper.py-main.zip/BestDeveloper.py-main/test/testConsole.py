import console
console.log("Does not run on IDLE.")
console.warn("Does not run on IDLE.")
console.error("Does not run on IDLE.")
console.info("Does not run on IDLE.")
