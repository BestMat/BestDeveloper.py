import sys 
print("Output from Python: ") 
print("First name: " + sys.argv[1]) 
print("Last name: " + sys.argv[2]) 
